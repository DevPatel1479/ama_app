import 'dart:async';
import 'dart:math';

import 'package:ama_legal_solutions/config/constants/app_assets_constants.dart';
import 'package:ama_legal_solutions/custom_messages_widgets/custom_flushbar_message.dart';
import 'package:ama_legal_solutions/custom_widgets/bottom_navigation.dart';

import 'package:ama_legal_solutions/custom_widgets/golden_light_theme_layout.dart';
import 'package:ama_legal_solutions/custom_widgets/login_required_dialog.dart';
import 'package:ama_legal_solutions/db/storage/local/local_storage_helper.dart';
import 'package:ama_legal_solutions/models/question_model.dart';
import 'package:ama_legal_solutions/provider/ama/answer_provider.dart';
import 'package:ama_legal_solutions/provider/ama/comment_provider.dart';
import 'package:ama_legal_solutions/provider/ama/delete_question_provider.dart';
import 'package:ama_legal_solutions/provider/ama/question_provider.dart';
import 'package:ama_legal_solutions/provider/profile/profile_photo_provider.dart';
import 'package:ama_legal_solutions/provider/theme/theme_provider.dart';
import 'package:ama_legal_solutions/provider/user_role/real_time_role_provider.dart';
import 'package:ama_legal_solutions/routes/app_paths_screen.dart';
import 'package:ama_legal_solutions/routes/app_screen_names.dart';
import 'package:ama_legal_solutions/screens/roles/user/dark_theme/dark_user_home_screen.dart'
    show RealtimeImageCarousel;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';

import 'package:ama_legal_solutions/screens/features/dark_theme/dark_ama_screen.dart'
    show
        InlineCommentsSection,
        buildLinkText,
        filterQuestionsCompute,
        showDeleteConfirmDialog,
        timeAgo,
        buildAvatar;
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

class _AskQuestionButton extends StatelessWidget {
  final VoidCallback onPressed;
  final double scaleFactor;

  const _AskQuestionButton({
    required this.onPressed,
    required this.scaleFactor,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(17),
        onTap: onPressed,
        child: Container(
          padding: EdgeInsets.symmetric(
            horizontal: 24 * scaleFactor,
            vertical: 12 * scaleFactor,
          ),
          decoration: BoxDecoration(
            color: const Color(0xFF2D2319),
            borderRadius: BorderRadius.circular(17),
            // boxShadow: [
            //   BoxShadow(
            //     color: Colors.black.withOpacity(0.51),
            //     blurRadius: 8.9,
            //     spreadRadius: 0,
            //   ),
            //   // Top inset highlight
            //   // const BoxShadow(
            //   //   color: Color.fromRGBO(232, 232, 232, 0.26),
            //   //   offset: Offset(0, -3),
            //   //   blurRadius: 13.8,
            //   // ),

            //   // Bottom inset highlight
            //   // const BoxShadow(
            //   //   color: Color.fromRGBO(232, 232, 232, 0.26),
            //   //   offset: Offset(0, 4),
            //   //   blurRadius: 13.8,
            //   // ),
            // ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                "Ask AMA",
                style: GoogleFonts.outfit(
                  fontSize: 14 * scaleFactor,
                  fontWeight: FontWeight.w500,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class LightAmaScreen extends StatefulWidget {
  final String? tappedQuestionId;
  final String? tappedCommentId;
  const LightAmaScreen({
    super.key,
    this.tappedQuestionId,
    this.tappedCommentId,
  });
  @override
  _LightAmaScreenState createState() => _LightAmaScreenState();
}

class _LightAmaScreenState extends State<LightAmaScreen>
    with SingleTickerProviderStateMixin {
  final ScrollController _scrollController = ScrollController();
  String? _activeFilter = "all";
  String? _openedCommentQuestionId;
  final Map<String, GlobalKey> _questionKeys = {};

  /// track which question ids are COLLAPSED. Default: expanded (not present in set)
  final Set<String> _collapsedIds = {};

  bool _initialFetchDone = false;
  String? userName, userRole, userPhone, profilImgUrl;
  // bool _expanded = false; // for view more/less toggle
  // late AnimationController _animationController;
  // late Animation<double> _animation;
  // Firestore real-time subscription
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>?
  _questionsSubscription;

  // final Map<String, int> _commentsCountMap = {};

  // Keep a reference to the provider to avoid looking up context inside the stream callback
  late final QuestionProvider _providerRef;

  Timer? _debounce;
  Timer? _searchDebounce;
  bool _isSearching = false;
  String _searchQuery = "";

  List _filteredQuestions = [];
  // Track if we're doing initial load vs real-time update
  bool _isInitialLoading = true;
  final TextEditingController _searchController = TextEditingController();
  String? _highlightedQuestionId;
  Timer? _highlightTimer;

  @override
  void initState() {
    super.initState();
    fetchUserDataFromLocal();
    // _animationController = AnimationController(
    //   duration: const Duration(milliseconds: 600),
    //   vsync: this,
    // );
    // _animation = CurvedAnimation(
    //   parent: _animationController,
    //   curve: Curves.easeInOut,
    // );
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      _providerRef = context.read<QuestionProvider>();
      if (!_initialFetchDone) {
        final provider = context.read<QuestionProvider>();
        // Use a special method for initial load that won't trigger loading state for real-time updates
        _loadInitialQuestions();
        _initialFetchDone = true;
      }
      _attachQuestionsListener();
      final phone = await LocalStorageHelper.getString("userPhone");
      final role = await LocalStorageHelper.getString("userRole");
      if (!mounted) return;
      if (phone != null && role != null) {
        final profileProv = context.read<ProfileProvider>();

        if (!profileProv.hasProfilePhoto) {
          profileProv.fetchProfilePhoto(context, phone: phone, role: role);
        }
      }
    });

    _scrollController.addListener(() {
      final provider = context.read<QuestionProvider>();

      if (_scrollController.position.pixels >=
          _scrollController.position.maxScrollExtent - 200) {
        if (_searchQuery.isNotEmpty) {
          // 🔍 SEARCH PAGINATION
          if (provider.searchHasMore && !provider.isSearching) {
            provider.searchQuestions(context, term: _searchQuery);
          }
        } else {
          // 🧠 NORMAL PAGINATION
          if (provider.hasMore && !provider.isLoading) {
            provider.fetchQuestions(context);
          }
        }
      }
    });
    _searchController.addListener(() {
      setState(() {}); // rebuild UI when text changes
    });
    if (widget.tappedQuestionId != null) {
      Future.delayed(const Duration(milliseconds: 700), () {
        if (!mounted) return;

        /// 🔥 If comment deep link → open comments & highlight COMMENT (not question)
        if (widget.tappedCommentId != null) {
          _openCommentsAndScrollToQuestion(widget.tappedQuestionId!);
        }
        /// 🔥 Else → highlight QUESTION only
        else {
          _scrollToAndHighlightQuestion(widget.tappedQuestionId!);
        }
      });
    }
  }

  void _openCommentsAndScrollToQuestion(String questionId) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final key = _questionKeys[questionId];
      final ctx = key?.currentContext;

      if (ctx != null) {
        // Scroll to the question first
        Scrollable.ensureVisible(
          ctx,
          duration: const Duration(milliseconds: 600),
          curve: Curves.easeInOut,
          alignment: 0.2,
        );

        // Open comments
        final commentProvider = context.read<CommentProvider>();
        commentProvider.clearExistingComments();
        commentProvider.fetchComments(questionId, reset: true);

        setState(() {
          _openedCommentQuestionId = questionId;
        });
      } else {
        // Retry until widget is mounted
        Future.delayed(const Duration(milliseconds: 300), () {
          if (mounted) _openCommentsAndScrollToQuestion(questionId);
        });
      }
    });
  }

  void _scrollToAndHighlightQuestion(String questionId) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final key = _questionKeys[questionId];
      final ctx = key?.currentContext;

      if (ctx != null) {
        Scrollable.ensureVisible(
          ctx,
          duration: const Duration(milliseconds: 600),
          curve: Curves.easeInOut,
          alignment: 0.2,
        );

        setState(() {
          _highlightedQuestionId = questionId;
        });

        _highlightTimer?.cancel();
        _highlightTimer = Timer(const Duration(seconds: 2), () {
          if (mounted) {
            setState(() => _highlightedQuestionId = null);
          }
        });
      } else {
        // 🔁 Retry if widget not built yet (pagination / async load)
        Future.delayed(const Duration(milliseconds: 300), () {
          if (mounted) _scrollToAndHighlightQuestion(questionId);
        });
      }
    });
  }

  Future<void> _loadInitialQuestions() async {
    if (!mounted) return;
    setState(() {
      _isInitialLoading = true;
    });
    await _providerRef.fetchQuestions(context, reset: true);
    if (!mounted) return;
    setState(() {
      _isInitialLoading = false;
    });
  }

  void fetchUserDataFromLocal() async {
    final name = await LocalStorageHelper.getString("userName");
    final role = await LocalStorageHelper.getString("userRole");
    final phone = await LocalStorageHelper.getString("userPhone");
    final profile = await LocalStorageHelper.getString("profile_photo_url");

    setState(() {
      userName = name;
      userRole = role;
      userPhone = phone;
      profilImgUrl = profile;
    });
    // print("user role set $userRole");
  }

  // void _toggleExpansion() {
  //   setState(() {
  //     _expanded = !_expanded;
  //     if (_expanded) {
  //       _animationController.forward();
  //     } else {
  //       _animationController.reverse();
  //     }
  //   });
  // }

  void _attachQuestionsListener() {
    if (_questionsSubscription != null) return;

    // Keep the same ordering & page size as your paginated API first page.
    final query = FirebaseFirestore.instance
        .collection('questions')
        .orderBy('timestamp', descending: true)
        .limit(10);

    _questionsSubscription = query.snapshots().listen(
      (QuerySnapshot<Map<String, dynamic>> snapshot) {
        if (!mounted) return;

        for (final change in snapshot.docChanges) {
          try {
            final doc = change.doc;
            // doc.data() may be null, so default to an empty map
            final Map<String, dynamic> data = doc.data() ?? <String, dynamic>{};

            final map = <String, dynamic>{
              'id': doc.id,
              // use data['field'] which if missing will be null — your Question.fromJson
              // should handle nulls. You can also provide defaults here if you prefer.
              'userId': data['userId'],
              'userName': data['userName'],
              'userRole': data['userRole'],
              'phone': data['phone'],
              'profileImgUrl': data['profileImgUrl'],
              'content': data['content'],
              // normalize timestamp safely (function returns 0 when can't parse)
              'timestamp': _normalizeTimestampField(data['timestamp']),
              'answer': data['answer'],
              'commentsCount': data['commentsCount'] ?? 0,
            };

            final qObj = Question.fromJson(map);

            if (change.type == DocumentChangeType.added) {
              _providerRef.upsertQuestion(qObj);
            } else if (change.type == DocumentChangeType.modified) {
              _providerRef.upsertQuestion(qObj);
            } else if (change.type == DocumentChangeType.removed) {
              _providerRef.removeQuestionById(qObj.id);
            }
          } catch (e) {
            // Helpful logging during development — remove or lower log level in prod
            // print('Realtime parse error for doc ${change.doc.id}: $e\n$st');
          }
        }
      },
      onError: (err) {
        // optionally log
        // print('Questions listener error: $err');
      },
    );
  }

  /// helper to normalize timestamp field returned by Firestore:
  /// Accepts int (ms or seconds) or Timestamp instance, returns milliseconds int
  int _normalizeTimestampField(dynamic ts) {
    if (ts == null) return 0;
    if (ts is int) {
      // If seconds, convert to milliseconds
      if (ts < 1000000000000) return ts * 1000;
      return ts;
    }
    // Cloud Firestore Timestamp (from package cloud_firestore)
    try {
      // ts may be a Timestamp with toDate() method
      final date = ts.toDate();
      return date.millisecondsSinceEpoch;
    } catch (_) {
      // fallback: try double
      try {
        final d = (ts as num).toInt();
        if (d < 1000000000000) return d * 1000;
        return d;
      } catch (_) {
        return 0;
      }
    }
  }

  // Handle real-time updates without showing loading indicator
  // Future<void> _handleRealtimeUpdate() async {
  //   try {
  //     // Use the silent method
  //     await _providerRef.fetchQuestionsSilently(context, reset: true);
  //   } catch (e) {
  //     // Silently handle errors for real-time updates
  //     // print('Silent update error: $e');
  //   }
  // }

  Future<void> _detachQuestionsListener() async {
    await _questionsSubscription?.cancel();
    _questionsSubscription = null;
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _searchController.dispose();
    _debounce?.cancel();
    _detachQuestionsListener();

    super.dispose();
  }

  void _onSearchChanged() {
    final q = _searchController.text.trim();
    // Debounce: wait 300ms after last keystroke
    _searchDebounce?.cancel();
    _searchDebounce = Timer(const Duration(milliseconds: 300), () {
      if (!mounted) return;
      setState(() => _searchQuery = q);
      // start searching
      _doSearch(q);
    });
  }

  Future<void> _doSearch(String query) async {
    // only search by content
    final q = query.trim();
    if (q.isEmpty) {
      if (!mounted) return;
      setState(() {
        _filteredQuestions = [];
        _isSearching = false;
        _searchQuery = '';
      });
      return;
    }

    setState(() {
      _isSearching = true;
      _filteredQuestions = [];
      _searchQuery = q;
    });

    try {
      final provider = context.read<QuestionProvider>();

      // Convert provider.questions (Question objects) into plain Maps for compute
      final rawList = provider.questions.map((qItem) {
        final map = <String, dynamic>{
          'id': qItem.id,
          'userId': qItem.userId,
          'userName': qItem.userName,
          'userRole': qItem.userRole,
          'phone': qItem.phone,
          'profileImgUrl': qItem.profileImgUrl,
          'content': qItem.content,
          'timestamp': qItem.timestamp,
          'commentsCount': qItem.commentsCount,
          'answer': qItem.answer != null
              ? {
                  'content': qItem.answer!.content,
                  'answered_by': qItem.answer!.answeredBy,
                  'role': qItem.answer!.role,
                  'timestamp': qItem.answer!.timestamp,
                }
              : null,
        };
        return map;
      }).toList();

      List<Map<String, dynamic>> matchedMaps;

      // On web, compute/isolate is not available - do synchronous filter
      if (kIsWeb) {
        final qLower = q.toLowerCase();
        matchedMaps = rawList.where((m) {
          final content = (m['content'] ?? '').toString().toLowerCase();
          return content.contains(qLower);
        }).toList();
      } else {
        // Run the filtering in a background isolate to avoid UI jank on large lists
        final res = await compute(filterQuestionsCompute, {
          'raw': rawList,
          'q': q,
        });
        matchedMaps = List<Map<String, dynamic>>.from(res);
      }

      // Convert back to Question objects (using your factory)
      final matchedQuestions = matchedMaps
          .map((m) => Question.fromJson(m))
          .toList();

      if (!mounted) return;
      setState(() {
        _filteredQuestions = matchedQuestions;
        _isSearching = false;
      });
    } catch (e) {
      // On error just stop searching; keep UX alive
      if (!mounted) return;
      setState(() {
        _filteredQuestions = [];
        _isSearching = false;
      });
      // optional: print or log e/st
      // print('Search error: $e\n$st');
    }
  }

  void _collapse(String id) {
    setState(() => _collapsedIds.add(id));
  }

  void _expand(String id) {
    setState(() => _collapsedIds.remove(id));
  }

  String _formatTimestamp(int? timestampMs) {
    if (timestampMs == null) return '';
    try {
      final dt = DateTime.fromMillisecondsSinceEpoch(timestampMs);
      return DateFormat('dd MMM yyyy, hh:mm a').format(dt);
    } catch (_) {
      return '';
    }
  }

  bool _canUserAddAnswer() {
    final r = userRole?.toLowerCase() ?? '';
    // print("user role $r");
    return r == 'admin' || r == 'advocate' || r == "legal_expert";
  }

  bool _questionHasNoAnswer(Question question) {
    final ans = question.answer;
    if (ans == null) return true;
    final content = (ans.content).toString().trim();
    return content.isEmpty;
  }

  /// Dialog box for adding an answer
  void _showAddAnswerDialog(
    BuildContext context,
    String questionId,
    String answeredBy,
    String role,
    String questionOwnerPhone,
  ) {
    final TextEditingController _controller = TextEditingController();

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        final screenWidth = MediaQuery.of(context).size.width;
        final screenHeight = MediaQuery.of(context).size.height;

        return AlertDialog(
          backgroundColor: Colors.black,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: const BorderSide(color: Color(0xFFD29F2A), width: 1),
          ),
          title: Text(
            "Add Your Answer",
            style: GoogleFonts.outfit(
              color: Colors.white,
              fontSize: screenWidth * 0.05,
              fontWeight: FontWeight.w600,
            ),
          ),
          content: SizedBox(
            width: screenWidth * 0.8,
            child: TextField(
              textInputAction: TextInputAction.done,
              controller: _controller,
              maxLines: 5,
              minLines: 3,
              style: GoogleFonts.outfit(color: Colors.white),
              decoration: InputDecoration(
                hintText: "Type your answer here...",
                hintStyle: GoogleFonts.outfit(
                  color: Colors.white54,
                  fontSize: screenWidth * 0.035,
                ),
                filled: true,
                fillColor: Colors.grey.shade900,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
          ),
          actionsPadding: EdgeInsets.symmetric(
            horizontal: screenWidth * 0.04,
            vertical: screenHeight * 0.01,
          ),
          actions: [
            // Cancel Button
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text(
                "Cancel",
                style: GoogleFonts.outfit(
                  color: Colors.white70,
                  fontSize: screenWidth * 0.04,
                ),
              ),
            ),

            // Add Answer Button (with loading)
            Consumer<AnswerProvider>(
              builder: (context, answerProvider, _) {
                return ElevatedButton(
                  onPressed: answerProvider.isLoading
                      ? null
                      : () async {
                          final content = _controller.text.trim();
                          if (content.isEmpty) {
                            showCustomMessage(
                              context,
                              "Please enter an answer",
                              true,
                            );
                            return;
                          }

                          await answerProvider.addOrUpdateAnswer(
                            context: context,
                            questionId: questionId,
                            content: content,
                            answeredBy: answeredBy,
                            role: role,
                            questionOwnerPhone: questionOwnerPhone,
                          );

                          if (!answerProvider.isLoading) {
                            await Future.delayed(Duration(seconds: 2));
                            Navigator.pop(
                              context,
                            ); // Close dialog after success
                          }
                        },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFD29F2A),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    padding: EdgeInsets.symmetric(
                      horizontal: screenWidth * 0.05,
                      vertical: screenHeight * 0.012,
                    ),
                  ),
                  child: answerProvider.isLoading
                      ? SizedBox(
                          width: screenWidth * 0.05,
                          height: screenWidth * 0.05,
                          child: const CircularProgressIndicator(
                            color: Colors.black,
                            strokeWidth: 2,
                          ),
                        )
                      : Text(
                          "Add",
                          style: GoogleFonts.outfit(
                            color: Colors.black,
                            fontSize: screenWidth * 0.04,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                );
              },
            ),
          ],
        );
      },
    );
  }

  Widget buildDoubtItem({
    required BuildContext context,
    required double screenWidth,
    required double screenHeight,
    required String userName,
    required String askedTime,
    required String fromTag,
    required String description,
  }) {
    return Container(
      width: double.infinity,
      margin: EdgeInsets.only(bottom: screenHeight * 0.02),
      padding: EdgeInsets.all(screenWidth * 0.04),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(15),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Top Row with user info and "From User" badge
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Image.asset(
                AppAssets.whiteUserIcon,
                width: screenWidth * 0.10,
                height: screenWidth * 0.10,
              ),
              SizedBox(width: screenWidth * 0.04),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      userName,
                      style: GoogleFonts.outfit(
                        fontSize: screenWidth * 0.035,
                        fontWeight: FontWeight.w500,
                        color: Colors.black,
                      ),
                    ),
                    SizedBox(height: screenHeight * 0.005),
                    Text(
                      askedTime,
                      style: GoogleFonts.outfit(
                        fontSize: screenWidth * 0.025,
                        fontWeight: FontWeight.w400,
                        color: Colors.black,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                height: screenHeight * 0.025,
                padding: EdgeInsets.symmetric(
                  vertical: screenHeight * 0.003,
                  horizontal: screenWidth * 0.04,
                ),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),

                  border: fromTag == "From User"
                      ? Border.all(color: const Color(0xFF8383F6), width: 1)
                      : Border.all(color: const Color(0xFF04C527), width: 1),
                ),
                alignment: Alignment.center,
                child: Text(
                  fromTag,
                  style: GoogleFonts.outfit(
                    fontSize: screenWidth * 0.03,
                    fontWeight: FontWeight.w400,
                    color: fromTag == "From User"
                        ? const Color(0xFF8383F6)
                        : const Color(0xFF04C527),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: screenHeight * 0.015),
          // Description text
          Text(
            description,
            style: GoogleFonts.outfit(
              fontSize: screenWidth * 0.03,
              fontWeight: FontWeight.w400,
              color: Colors.black,
              height: 1.5,
            ),
          ),
          SizedBox(height: screenHeight * 0.015),
          // Like and Answer row
          Row(
            children: [
              Image.asset(
                AppAssets.likeHeartIcon,
                width: screenWidth * 0.04,
                height: screenWidth * 0.04,
                color: Colors.black,
              ),
              SizedBox(width: screenWidth * 0.02),
              Text(
                "Like",
                style: GoogleFonts.outfit(
                  fontSize: screenWidth * 0.025,
                  fontWeight: FontWeight.w400,
                  color: Colors.black,
                ),
              ),
              SizedBox(width: screenWidth * 0.05),
              Image.asset(
                AppAssets.answerIcon,
                width: screenWidth * 0.04,
                height: screenWidth * 0.04,
                color: Colors.black,
              ),
              SizedBox(width: screenWidth * 0.02),
              Text(
                "Answer",
                style: GoogleFonts.outfit(
                  fontSize: screenWidth * 0.025,
                  fontWeight: FontWeight.w400,
                  color: Colors.black,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void toggleComments(String questionId) {
    setState(() {
      if (_openedCommentQuestionId == questionId) {
        _openedCommentQuestionId = null;
      } else {
        _openedCommentQuestionId = questionId;
      }
    });
  }

  Widget _buildFilterButton(
    String label,
    String filterKey,
    double screenWidth,
    double screenHeight,
  ) {
    final bool isActive = _activeFilter == filterKey;

    // Responsive font & padding with min/max caps
    final double fontSize = min(16, max(12, screenWidth * 0.04)); // 12-16px
    final double horizontalPadding = min(20, max(12, screenWidth * 0.04));
    final double verticalPadding = min(10, max(6, screenHeight * 0.012));

    return GestureDetector(
      onTap: () {
        setState(() {
          _activeFilter = isActive ? null : filterKey;
        });
      },
      child: Container(
        padding: EdgeInsets.symmetric(
          vertical: verticalPadding,
          horizontal: horizontalPadding,
        ),
        decoration: BoxDecoration(
          color: const Color(0xFF2D2319),
          borderRadius: BorderRadius.circular(9),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.33), blurRadius: 12.5),
          ],
          border: isActive
              ? Border.all(color: const Color(0xFFD29F2A), width: 2)
              : null,
        ),
        child: Center(
          child: Text(
            label,
            style: GoogleFonts.outfit(
              fontSize: fontSize,
              fontWeight: FontWeight.w400,
              color: Colors.white,
            ),
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }

  void scrollToQuestion(String questionId) {
    final key = _questionKeys[questionId];
    if (key == null) return;

    final context = key.currentContext;
    if (context == null) return;

    WidgetsBinding.instance.addPostFrameCallback((_) {
      Scrollable.ensureVisible(
        context,
        duration: const Duration(milliseconds: 350),
        curve: Curves.easeInOut,
        alignment: 0.25, // keeps input above keyboard
      );
    });
  }

  List<Map<String, String>> _getDropdownValues() {
    final role = userRole?.toLowerCase() ?? "";

    if (role == "user" || role == "client" || role == "guest") {
      return [
        {'key': 'all', 'label': 'All'}, // default: all questions
        {'key': 'unanswered', 'label': 'Unanswered'},
        {'key': 'posted_by_me', 'label': 'My Questions'},
        {'key': 'answered', 'label': 'Answered'},
      ];
    } else {
      // admin / advocate
      return [
        {'key': 'all', 'label': 'All'}, // default: all questions
        {'key': 'unanswered', 'label': 'Unanswered'},
        {'key': 'answered_by_me', 'label': 'Answered by me'},
        {'key': 'answered', 'label': 'Answered'},
      ];
    }
  }

  // Widget _buildSearchBar(double screenWidth, double screenHeight) {
  //   return Container(
  //     margin: EdgeInsets.only(bottom: screenHeight * 0.02),
  //     padding: EdgeInsets.symmetric(
  //       horizontal: screenWidth * 0.04,
  //       vertical: screenHeight * 0.018,
  //     ),
  //     decoration: BoxDecoration(
  //       borderRadius: BorderRadius.circular(15),

  //       /// ✅ BORDER (light theme)
  //       border: Border.all(color: const Color(0xFF2D2319)),

  //       /// ✅ BACKGROUND (light glass)
  //       color: const Color.fromRGBO(45, 35, 25, 0.07),
  //     ),
  //     child: Row(
  //       children: [
  //         /// 🔍 SEARCH ICON (BLACK)
  //         Icon(Icons.search, color: Colors.black, size: screenWidth * 0.05),

  //         SizedBox(width: screenWidth * 0.03),

  //         /// ✍️ TEXT FIELD
  //         Expanded(
  //           child: TextField(
  //             controller: _searchController,
  //             onChanged: (value) {
  //               if (_searchDebounce?.isActive ?? false) {
  //                 _searchDebounce!.cancel();
  //               }

  //               _searchDebounce = Timer(const Duration(milliseconds: 500), () {
  //                 final provider = context.read<QuestionProvider>();

  //                 if (value.trim().isEmpty) {
  //                   provider.clearSearch();
  //                   setState(() {
  //                     _searchQuery = "";
  //                   });
  //                   return;
  //                 }

  //                 setState(() {
  //                   _searchQuery = value;
  //                 });

  //                 final isNewSearch =
  //                     value.trim().toLowerCase() != provider.currentSearchTerm;

  //                 provider.searchQuestions(
  //                   context,
  //                   term: value.trim().toLowerCase(),
  //                   reset: isNewSearch,
  //                 );
  //               });

  //               setState(() {});
  //             },

  //             /// ✅ TEXT COLOR BLACK
  //             style: GoogleFonts.outfit(
  //               color: Colors.black,
  //               fontSize: 16,
  //               fontWeight: FontWeight.w400,
  //               height: 1,
  //             ),

  //             decoration: InputDecoration(
  //               isDense: true,
  //               border: InputBorder.none,

  //               /// ✅ HINT TEXT BLACK (slightly faded)
  //               hintText: "Search legal queries…",
  //               hintStyle: GoogleFonts.outfit(
  //                 color: Colors.black.withOpacity(0.5),
  //                 fontSize: 16,
  //                 fontWeight: FontWeight.w400,
  //                 height: 1,
  //               ),

  //               contentPadding: EdgeInsets.zero,
  //             ),
  //           ),
  //         ),

  //         /// ❌ CLEAR BUTTON (also black)
  //         if (_searchController.text.isNotEmpty)
  //           GestureDetector(
  //             onTap: () {
  //               _searchController.clear();

  //               context.read<QuestionProvider>().clearSearch();

  //               setState(() {
  //                 _searchQuery = "";
  //               });
  //             },
  //             child: Padding(
  //               padding: EdgeInsets.only(left: screenWidth * 0.02),
  //               child: Icon(
  //                 Icons.close,
  //                 color: Colors.black.withOpacity(0.6),
  //                 size: screenWidth * 0.045,
  //               ),
  //             ),
  //           ),
  //       ],
  //     ),
  //   );
  // }

  double _getTextWidth(String text, double fontSize) {
    final TextPainter textPainter = TextPainter(
      text: TextSpan(
        text: text,
        style: GoogleFonts.outfit(
          fontSize: fontSize,
          fontWeight: FontWeight.w400,
        ),
      ),
      maxLines: 1,
      textDirection: Directionality.of(context),
    )..layout();

    return textPainter.size.width;
  }

  Widget buildFilters(double screenWidth, double screenHeight) {
    final filters = _getDropdownValues();

    return Padding(
      padding: EdgeInsets.only(
        bottom: screenHeight * 0.02,
        left: screenWidth * 0.02,
        right: screenWidth * 0.02,
      ),
      child: SizedBox(
        height: screenHeight * 0.06,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          physics: const BouncingScrollPhysics(),
          itemCount: filters.length,
          separatorBuilder: (_, __) => SizedBox(width: screenWidth * 0.06),
          itemBuilder: (context, i) {
            final filter = filters[i];
            final bool isSelected = _activeFilter == filter['key'];

            final textWidth = _getTextWidth(
              filter['label']!,
              screenWidth * 0.04,
            );

            return GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () {
                setState(() {
                  _activeFilter = filter['key']!;
                });
              },
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  /// 🔤 LABEL TEXT
                  AnimatedDefaultTextStyle(
                    duration: const Duration(milliseconds: 250),
                    style: GoogleFonts.outfit(
                      /// ✅ LIGHT MODE COLORS
                      color: isSelected
                          ? const Color(0xFF2D2319) // active
                          : const Color(0xB22D2319), // 70% opacity
                      fontSize: screenWidth * 0.04,
                      fontWeight: FontWeight.w400,
                      height: 1,
                    ),
                    child: Text(filter['label']!),
                  ),

                  SizedBox(height: screenHeight * 0.008),

                  /// 🟡 DASH (same as active color now)
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 250),
                    height: 4,
                    width: isSelected ? textWidth : 0,
                    decoration: BoxDecoration(
                      color: const Color(0xFF2D2319), // ✅ match active text
                      borderRadius: BorderRadius.circular(58),
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(
      SystemUiOverlayStyle(
        statusBarColor: Color(0xFFD29F2A),
        statusBarIconBrightness: Brightness.dark,
        statusBarBrightness: Brightness.light,
      ),
    );

    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;
    const scaleFactor = 0.85;
    const searchFieldScaleFactor = 0.75;

    final navHeight = (screenWidth * 0.18).clamp(56.0, 84.0);
    final bottomInset = MediaQuery.of(context).padding.bottom;
    final contentBottomPadding =
        navHeight + (bottomInset > 0 ? bottomInset * 0.6 : 0.0) + 12.0;
    final headerVisualHeight = screenHeight * 0.03; // tweak if you need taller
    final appBarHeight =
        MediaQuery.of(context).padding.top + headerVisualHeight;
    final role = context.watch<RealTimeRoleProvider>().role;
    userRole = role;
    final keyboardHeight = MediaQuery.of(context).viewInsets.bottom;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      extendBody: true,

      backgroundColor: Color(0xFFF8BD00),
      appBar: AppBar(
        elevation: 0,
        backgroundColor: const Color.fromARGB(255, 244, 206, 83),
        surfaceTintColor: Colors.transparent,
        automaticallyImplyLeading: false,
        systemOverlayStyle: const SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: Brightness.dark,
          statusBarBrightness: Brightness.light,
        ),

        // ⭐ NATIVE WAY TO ROUND ONLY BOTTOM
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
            bottomLeft: Radius.circular(screenWidth * 0.07),
            bottomRight: Radius.circular(screenWidth * 0.07),
          ),
        ),

        titleSpacing: 0,
        toolbarHeight: kToolbarHeight + screenHeight * 0.07,

        title: Padding(
          padding: EdgeInsets.only(
            top: MediaQuery.of(context).padding.top,
            right: screenWidth * 0.04 * scaleFactor,
            bottom: screenHeight * 0.012 * scaleFactor,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              /// fixed header + search area
              Column(
                children: [
                  Row(
                    children: [
                      IconButton(
                        padding: EdgeInsets.zero, // remove default padding

                        icon: Image.asset(
                          AppAssets.backArrowIcon,
                          width: screenWidth * 0.06,
                          height: screenWidth * 0.06,
                          fit: BoxFit.contain,
                          color: Colors.black,
                        ),
                        onPressed: () =>
                            context.go(AppPathsForScreen.userHomePath),
                        splashRadius: 24, // optional, makes tap area bigger
                      ),

                      // SizedBox(width: screenWidth * 0.06 * scaleFactor),
                      Text(
                        "AMA",
                        style: GoogleFonts.outfit(
                          fontSize:
                              (screenWidth / 100) *
                              6.5 *
                              scaleFactor, // proportional but safe scaling
                          fontWeight: FontWeight.w600,
                          color: Colors.black,
                          height: 1.2, // keeps it compact for AppBar
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.center,
                      ),
                      Spacer(),

                      /// Ask Doubt Button at top-right
                      _AskQuestionButton(
                        scaleFactor: scaleFactor,
                        onPressed: () {
                          if (userRole?.toLowerCase() == "guest") {
                            final isDark = Provider.of<ThemeProvider>(
                              context,
                              listen: false,
                            ).isDarkMode;

                            showDialog(
                              context: context,
                              builder: (_) => LoginRequiredDialog(
                                isDarkTheme: isDark,
                                onLoginPressed: () {
                                  Navigator.pop(context);
                                  context.goNamed(AppScreenNames.logIn);
                                },
                              ),
                            );
                            return;
                          }

                          context.pushNamed(
                            AppScreenNames.raiseQuery,
                            queryParameters: {"isQuestionPosting": "true"},
                          );
                        },
                      ),
                    ],
                  ),

                  SizedBox(height: screenHeight * 0.02),
                  // Padding(
                  //   padding: EdgeInsets.only(left: screenWidth * 0.035),
                  //   child: _buildSearchBar(screenWidth, screenHeight),
                  // ),
                  // SizedBox(height: screenHeight * 0.03),
                  Padding(
                    padding: EdgeInsets.only(left: screenWidth * 0.035),
                    child: buildFilters(screenWidth, screenHeight),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),

      body: Stack(
        children: [
          Positioned.fill(
            child: SafeArea(
              bottom: false,

              child: GradientTopLayout(
                screenName: "home",
                keepExpanded: false,

                // headerContent: Container(
                //   width: double.infinity,

                //   padding: EdgeInsets.symmetric(
                //     horizontal: screenWidth * 0.04 * scaleFactor,
                //     vertical: screenHeight * 0.015 * scaleFactor,
                //   ),
                //   decoration: BoxDecoration(
                //     color: const Color(0xFFD29F2A),
                //     borderRadius: BorderRadius.only(
                //       bottomLeft: Radius.circular(
                //         screenWidth * 0.07,
                //       ), // ~responsive
                //       bottomRight: Radius.circular(
                //         screenWidth * 0.07,
                //       ), // ~responsive
                //     ),
                //   ),
                //   child: Column(
                //     children: [
                //       /// fixed header + search area
                //       Column(
                //         children: [
                //           Row(
                //             children: [
                //               GestureDetector(
                //                 onTap: () =>
                //                     context.go(AppPathsForScreen.userHomePath),
                //                 child: Image.asset(
                //                   AppAssets.backArrowIcon,
                //                   width: screenWidth * 0.05 * scaleFactor,
                //                   height: screenWidth * 0.05 * scaleFactor,
                //                   fit: BoxFit.contain,
                //                   color: Colors.black,
                //                 ),
                //               ),
                //               SizedBox(width: screenWidth * 0.12 * scaleFactor),
                //               Text(
                //                 "Ask Me Anything",
                //                 style: GoogleFonts.outfit(
                //                   fontSize:
                //                       (screenWidth / 100) *
                //                       6.5 *
                //                       scaleFactor, // proportional but safe scaling
                //                   fontWeight: FontWeight.w600,
                //                   color: Colors.black,
                //                   height: 1.2, // keeps it compact for AppBar
                //                 ),
                //                 maxLines: 1,
                //                 overflow: TextOverflow.ellipsis,
                //                 textAlign: TextAlign.center,
                //               ),
                //               Spacer(),

                //               /// Ask Doubt Button at top-right
                //               SizedBox(
                //                 width: screenWidth * 0.35 * scaleFactor,
                //                 height: screenHeight * 0.05 * scaleFactor,
                //                 child: ElevatedButton(
                //                   onPressed: () {
                //                     context.pushNamed(
                //                       AppScreenNames.raiseQuery,
                //                       queryParameters: {
                //                         "isQuestionPosting": "true",
                //                       },
                //                     );
                //                   },

                //                   style:
                //                       ElevatedButton.styleFrom(
                //                         padding: EdgeInsets.zero,
                //                         shape: RoundedRectangleBorder(
                //                           borderRadius: BorderRadius.circular(
                //                             41,
                //                           ),
                //                         ),
                //                         backgroundColor: Colors.transparent,
                //                         shadowColor: Colors.black.withOpacity(
                //                           0.3,
                //                         ),
                //                         elevation: 6,
                //                       ).copyWith(
                //                         backgroundColor:
                //                             MaterialStateProperty.all(
                //                               Colors.transparent,
                //                             ),
                //                       ),
                //                   child: Ink(
                //                     decoration: BoxDecoration(
                //                       color: Colors.black,
                //                       borderRadius: BorderRadius.circular(41),
                //                     ),
                //                     child: Container(
                //                       alignment: Alignment.center,
                //                       child: Text(
                //                         "Ask Question",
                //                         style: GoogleFonts.outfit(
                //                           fontSize: 14 * scaleFactor,
                //                           fontWeight: FontWeight.w500,
                //                           color: Colors.white,
                //                         ),
                //                       ),
                //                     ),
                //                   ),
                //                 ),
                //               ),
                //             ],
                //           ),
                //         ],
                //       ),
                //     ],
                //   ),
                // ),
                child: Padding(
                  padding: EdgeInsets.symmetric(
                    horizontal: screenWidth * 0.01 * scaleFactor,
                    // vertical: screenHeight * 0.012 * scaleFactor,
                  ),
                  child: Column(
                    children: [
                      // SizedBox(height: screenHeight * 0.03 * scaleFactor),
                      Expanded(
                        child: Consumer<QuestionProvider>(
                          builder: (context, provider, _) {
                            // Show initial loading only on first load
                            if (_isInitialLoading &&
                                provider.questions.isEmpty) {
                              return const Center(
                                child: CircularProgressIndicator(
                                  color: Colors.black,
                                ),
                              );
                            }

                            // choose source: show filtered results when searching, otherwise provider list
                            final List sourceList = (_searchQuery.isNotEmpty)
                                ? provider.searchResults
                                : provider.questions;

                            final List uniqueQuestions = [];
                            final seen = <String>{};
                            for (var item in sourceList) {
                              String? id;
                              if (item is Question) {
                                id = item.id;
                              } else if (item is Map && item['id'] != null) {
                                id = item['id'].toString();
                              } else {
                                // defensive fallback for dynamic objects
                                try {
                                  id = (item as dynamic).id as String?;
                                } catch (_) {
                                  id = null;
                                }
                              }
                              if (id == null || id.isEmpty) continue;
                              if (!seen.contains(id)) {
                                seen.add(id);
                                uniqueQuestions.add(item);
                              }
                            }

                            if (_searchQuery.isNotEmpty) {
                              /// 🔥 SHOW LOADER FIRST
                              if (provider.isSearching &&
                                  uniqueQuestions.isEmpty) {
                                return const Center(
                                  child: CircularProgressIndicator(
                                    color: Colors.black,
                                  ),
                                );
                              }

                              /// ❌ SHOW EMPTY ONLY AFTER SEARCH COMPLETES
                              if (!provider.isSearching &&
                                  uniqueQuestions.isEmpty) {
                                return const Center(
                                  child: Text(
                                    "No matching questions found",
                                    style: TextStyle(color: Colors.black),
                                  ),
                                );
                              }
                            } // Show message if filtered list is empty

                            // Show message if filtered list is empty
                            List __filteredQuestions = uniqueQuestions;
                            switch (_activeFilter) {
                              case 'all': // show all questions
                                __filteredQuestions = uniqueQuestions;
                                __filteredQuestions.sort(
                                  (a, b) => (b.timestamp ?? 0).compareTo(
                                    a.timestamp ?? 0,
                                  ),
                                );
                                break;

                              case 'unanswered':
                                __filteredQuestions = uniqueQuestions
                                    .where((q) => q.answer == null)
                                    .toList();
                                break;

                              case 'posted_by_me':
                                __filteredQuestions = uniqueQuestions
                                    .where((q) => q.phone == userPhone)
                                    .toList();
                                break;

                              case 'answered_by_me':
                                __filteredQuestions = uniqueQuestions
                                    .where(
                                      (q) =>
                                          q.answer != null &&
                                          q.answer!.answeredBy.toLowerCase() ==
                                              userName?.toLowerCase(),
                                    )
                                    .toList();
                                break;

                              case 'answered':
                                __filteredQuestions = uniqueQuestions
                                    .where((q) => q.answer != null)
                                    .toList();
                                break;

                              default:
                                __filteredQuestions = uniqueQuestions;
                            }
                            // Use filtered pagination only when not searching
                            final bool usePagination = _searchQuery.isEmpty;

                            // FIXED: Only add +1 to itemCount when actually loading more
                            final bool shouldShowLoader =
                                (_searchQuery.isEmpty &&
                                    provider.hasMore &&
                                    provider.isLoading) ||
                                (_searchQuery.isNotEmpty &&
                                    provider.searchHasMore &&
                                    provider.isSearching);

                            final int itemCount =
                                2 +
                                uniqueQuestions.length +
                                (shouldShowLoader ? 1 : 0);

                            return RefreshIndicator(
                              // edgeOffset:
                              //     MediaQuery.of(context).padding.top +
                              //     screenHeight *
                              //         0.07 + // same as ListView top padding
                              //     8,
                              onRefresh: () async {
                                // reset data and re-fetch from first page
                                await provider.fetchQuestionsSilently(
                                  context,
                                  reset: true,
                                );
                                // reset collapse state so everything is expanded after refresh
                                setState(() {
                                  _collapsedIds.clear();
                                  _filteredQuestions = [];
                                  _searchController.clear();
                                  _searchQuery = '';
                                  _isSearching = false;
                                });
                              },
                              child: ListView.builder(
                                controller: _scrollController,
                                padding: EdgeInsets.only(
                                  left: screenWidth * 0.04,
                                  right: screenWidth * 0.04,
                                  // top: screenHeight * 0.01,
                                  bottom:
                                      contentBottomPadding +
                                      keyboardHeight +
                                      screenHeight * 0.10,
                                ),
                                itemCount:
                                    1 + // carousel
                                    uniqueQuestions.length +
                                    (shouldShowLoader ? 1 : 0),
                                itemBuilder: (context, index) {
                                  // loader row (pagination)

                                  // if (index == 0) {
                                  //   final filters = _getDropdownValues();

                                  //   return Padding(
                                  //     padding: EdgeInsets.only(
                                  //       bottom: screenHeight * 0.02,
                                  //       left: screenWidth * 0.02,
                                  //       right: screenWidth * 0.02,
                                  //     ),
                                  //     child: Column(
                                  //       crossAxisAlignment:
                                  //           CrossAxisAlignment.start,
                                  //       children: [
                                  //         Text(
                                  //           "Filter by:",
                                  //           style: GoogleFonts.outfit(
                                  //             color: Colors.black87,
                                  //             fontSize: screenWidth * 0.04,
                                  //             fontWeight: FontWeight.w500,
                                  //           ),
                                  //         ),

                                  //         SizedBox(
                                  //           height: screenHeight * 0.012,
                                  //         ),

                                  //         SizedBox(
                                  //           height: screenHeight * 0.05,
                                  //           child: ListView.separated(
                                  //             scrollDirection: Axis.horizontal,
                                  //             physics:
                                  //                 const BouncingScrollPhysics(),
                                  //             itemCount: filters.length,
                                  //             separatorBuilder: (_, __) =>
                                  //                 SizedBox(
                                  //                   width: screenWidth * 0.025,
                                  //                 ),
                                  //             itemBuilder: (context, i) {
                                  //               final filter = filters[i];
                                  //               final bool isSelected =
                                  //                   _activeFilter ==
                                  //                   filter['key'];

                                  //               return GestureDetector(
                                  //                 onTap: () {
                                  //                   setState(() {
                                  //                     _activeFilter =
                                  //                         filter['key']!;
                                  //                   });
                                  //                 },
                                  //                 child: AnimatedContainer(
                                  //                   duration: const Duration(
                                  //                     milliseconds: 250,
                                  //                   ),
                                  //                   padding:
                                  //                       EdgeInsets.symmetric(
                                  //                         horizontal:
                                  //                             screenWidth *
                                  //                             0.04,
                                  //                         vertical:
                                  //                             screenHeight *
                                  //                             0.008,
                                  //                       ),
                                  //                   decoration: BoxDecoration(
                                  //                     color: isSelected
                                  //                         ? const Color(
                                  //                             0xFFFFC107,
                                  //                           ) // selected
                                  //                         : Colors
                                  //                               .white, // normal chip
                                  //                     borderRadius:
                                  //                         BorderRadius.circular(
                                  //                           30,
                                  //                         ),
                                  //                     border: Border.all(
                                  //                       color: isSelected
                                  //                           ? const Color(
                                  //                               0xFFFFC107,
                                  //                             )
                                  //                           : Colors.black12,
                                  //                     ),
                                  //                   ),
                                  //                   child: Center(
                                  //                     child: Text(
                                  //                       filter['label']!,
                                  //                       style:
                                  //                           GoogleFonts.outfit(
                                  //                             color: isSelected
                                  //                                 ? Colors.black
                                  //                                 : Colors
                                  //                                       .black87,
                                  //                             fontSize:
                                  //                                 screenWidth *
                                  //                                 0.035,
                                  //                             fontWeight:
                                  //                                 FontWeight
                                  //                                     .w500,
                                  //                           ),
                                  //                     ),
                                  //                   ),
                                  //                 ),
                                  //               );
                                  //             },
                                  //           ),
                                  //         ),
                                  //       ],
                                  //     ),
                                  //   );
                                  // }
                                  // Adjust actual index for carousel + filter row
                                  if (index == 0) {
                                    return Padding(
                                      padding: EdgeInsets.only(
                                        bottom: screenHeight * 0.02,
                                      ),
                                      child: RealtimeImageCarousel(
                                        type: "ama",
                                        height: screenHeight * 0.22,
                                      ),
                                    );
                                  }
                                  final int actualIndex = index - 1;

                                  // If filtered list is empty → show message
                                  if (__filteredQuestions.isEmpty) {
                                    // Only show message at the first "card index"
                                    if (actualIndex == 0) {
                                      return Padding(
                                        padding: EdgeInsets.only(
                                          top: screenHeight * 0.1,
                                        ),
                                        child: Center(
                                          child: Text(
                                            _activeFilter == "latest"
                                                ? "No latest questions found"
                                                : _activeFilter == "unanswered"
                                                ? "No unanswered questions found"
                                                : "No questions found",
                                            style: const TextStyle(
                                              color: Colors.black,
                                            ),
                                          ),
                                        ),
                                      );
                                    } else {
                                      return const SizedBox.shrink(); // prevent duplicate messages
                                    }
                                  }

                                  // 🟡 Pagination loader
                                  if (shouldShowLoader &&
                                      actualIndex == uniqueQuestions.length) {
                                    return const Padding(
                                      padding: EdgeInsets.symmetric(
                                        vertical: 24,
                                      ),
                                      child: Center(
                                        child: CircularProgressIndicator(
                                          color: Colors.black,
                                        ),
                                      ),
                                    );
                                  }

                                  // 🛡️ Safety
                                  if (actualIndex < 0 ||
                                      actualIndex >= uniqueQuestions.length) {
                                    return const SizedBox.shrink();
                                  }

                                  // Ensure actualIndex is safe for filtered list
                                  if (actualIndex >=
                                      __filteredQuestions.length) {
                                    return const SizedBox.shrink();
                                  }

                                  final question =
                                      __filteredQuestions[actualIndex];
                                  final questionId = question.id as String;
                                  final isExpanded = !_collapsedIds.contains(
                                    questionId,
                                  );
                                  final formattedDate = _formatTimestamp(
                                    question.timestamp as int?,
                                  );
                                  final showAddAnswerButton =
                                      _canUserAddAnswer() &&
                                      _questionHasNoAnswer(question);
                                  _questionKeys.putIfAbsent(
                                    questionId,
                                    () => GlobalKey(),
                                  );
                                  // determine answer preview limit (adjust as needed)
                                  final answerText =
                                      question.answer?.content ?? '';
                                  final int charLimit = screenWidth < 600
                                      ? 100
                                      : 160;
                                  final bool answerTooLong =
                                      answerText.length > charLimit;
                                  final String answerPreview = answerTooLong
                                      ? answerText
                                            .substring(0, charLimit)
                                            .trimRight()
                                      : answerText;

                                  // Inside your ListView.builder, replace the old card Container with this:
                                  final bool isHighlighted =
                                      _highlightedQuestionId == questionId;
                                  return AnimatedContainer(
                                    duration: const Duration(milliseconds: 400),
                                    key: _questionKeys[questionId],
                                    margin: const EdgeInsets.symmetric(
                                      vertical: 6,
                                    ),
                                    decoration: BoxDecoration(
                                      color: isHighlighted
                                          ? const Color.fromRGBO(
                                              210,
                                              159,
                                              42,
                                              0.35,
                                            )
                                          : const Color.fromARGB(
                                              255,
                                              217,
                                              188,
                                              121,
                                            ),
                                      borderRadius: BorderRadius.circular(15),
                                      border: isHighlighted
                                          ? Border.all(
                                              color: Colors.black.withOpacity(
                                                0.6,
                                              ),
                                              width: 2,
                                            )
                                          : null,

                                      boxShadow: [
                                        BoxShadow(
                                          color: // 👈 dark halo
                                          Colors.black.withOpacity(
                                            0.33,
                                          ),
                                          blurRadius: isHighlighted ? 28 : 12.5,
                                          spreadRadius: isHighlighted ? 4 : 0,
                                          offset: const Offset(0, 10),
                                        ),
                                        if (isHighlighted)
                                          BoxShadow(
                                            color: const Color(0xFFFFB703)
                                                .withOpacity(
                                                  0.8,
                                                ), // warm glow ring
                                            blurRadius: 16,
                                            spreadRadius: 2,
                                          ),
                                      ],
                                    ),
                                    padding: EdgeInsets.all(screenWidth * 0.03),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        /// TOP ROW: AVATAR + NAME + TIMESTAMP + ADD ANSWER BUTTON
                                        Row(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.center,
                                          children: [
                                            // CircleAvatar(
                                            //   radius: screenWidth * 0.04,
                                            //   backgroundColor:
                                            //       Colors.transparent,
                                            //   backgroundImage:
                                            //       (question.profileImgUrl !=
                                            //               null &&
                                            //           (question.profileImgUrl
                                            //                   as String)
                                            //               .isNotEmpty)
                                            //       ? NetworkImage(
                                            //           "${question.profileImgUrl}?v=${DateTime.now().millisecondsSinceEpoch}",
                                            //         )
                                            //       : AssetImage(
                                            //               AppAssets.userIcon,
                                            //             )
                                            //             as ImageProvider,
                                            // ),
                                            buildAvatar(
                                              question.userName ?? "N/A",
                                              question.profileImgUrl,
                                              screenWidth * 0.035,
                                              isLight: true,
                                            ),
                                            SizedBox(width: screenWidth * 0.03),
                                            Expanded(
                                              child: Text(
                                                question.userName ?? '',
                                                style: GoogleFonts.outfit(
                                                  color: Colors.black,
                                                  fontSize: screenWidth * 0.036,
                                                  fontWeight: FontWeight.w500,
                                                  height: 1.0,
                                                ),
                                                maxLines: 1,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                            ),

                                            if (userRole?.toLowerCase() ==
                                                "admin") ...[
                                              SizedBox(
                                                width: screenWidth * 0.02,
                                              ),

                                              Consumer<DeleteQuestionProvider>(
                                                builder: (_, deleteProvider, __) {
                                                  final isDeleting =
                                                      deleteProvider
                                                          .isDeleting &&
                                                      deleteProvider
                                                              .response
                                                              ?.questionId ==
                                                          question.id;

                                                  return GestureDetector(
                                                    onTap: isDeleting
                                                        ? null
                                                        : () async {
                                                            final confirm =
                                                                await showDeleteConfirmDialog(
                                                                  context,
                                                                  title:
                                                                      "Delete Question?",
                                                                  message:
                                                                      "This action cannot be undone.",
                                                                );

                                                            if (!confirm)
                                                              return;

                                                            final success = await deleteProvider
                                                                .deleteQuestion(
                                                                  questionId:
                                                                      question
                                                                          .id,
                                                                  role:
                                                                      userRole!,
                                                                );

                                                            if (success) {
                                                              context
                                                                  .read<
                                                                    QuestionProvider
                                                                  >()
                                                                  .removeQuestionById(
                                                                    questionId,
                                                                  );
                                                            }
                                                          },
                                                    child: isDeleting
                                                        ? const SizedBox(
                                                            width: 18,
                                                            height: 18,
                                                            child:
                                                                CircularProgressIndicator(
                                                                  strokeWidth:
                                                                      2,
                                                                  color: Colors
                                                                      .white,
                                                                ),
                                                          )
                                                        : const Icon(
                                                            Icons
                                                                .delete_outline,
                                                            color: Colors.black,
                                                            size: 20,
                                                          ),
                                                  );
                                                },
                                              ),
                                            ],

                                            // if (showAddAnswerButton)
                                            //   SizedBox(
                                            //     width: screenWidth * 0.03,
                                            //   ),
                                            // if (showAddAnswerButton)
                                            //   Container(
                                            //     height: screenHeight * 0.035,
                                            //     child: ElevatedButton(
                                            //       onPressed: () {
                                            //         _showAddAnswerDialog(
                                            //           context,
                                            //           questionId,
                                            //           userName!,
                                            //           userRole!,
                                            //           question.phone as String,
                                            //         );
                                            //       },
                                            //       style:
                                            //           ElevatedButton.styleFrom(
                                            //             padding:
                                            //                 EdgeInsets.zero,
                                            //             backgroundColor:
                                            //                 Colors.transparent,
                                            //             elevation: 0,
                                            //             shape: RoundedRectangleBorder(
                                            //               borderRadius:
                                            //                   BorderRadius.circular(
                                            //                     6,
                                            //                   ),
                                            //             ),
                                            //           ).copyWith(
                                            //             backgroundColor:
                                            //                 MaterialStateProperty.all(
                                            //                   Colors
                                            //                       .transparent,
                                            //                 ),
                                            //           ),
                                            //       child: Ink(
                                            //         decoration: BoxDecoration(
                                            //           gradient:
                                            //               const LinearGradient(
                                            //                 begin: Alignment
                                            //                     .centerLeft,
                                            //                 end: Alignment
                                            //                     .centerRight,
                                            //                 colors: [
                                            //                   Color(0xFFD29F2A),
                                            //                   Color(0xFFFFFFFF),
                                            //                 ],
                                            //               ),
                                            //           borderRadius:
                                            //               BorderRadius.circular(
                                            //                 6,
                                            //               ),
                                            //         ),
                                            //         child: Container(
                                            //           padding:
                                            //               const EdgeInsets.symmetric(
                                            //                 horizontal: 8,
                                            //                 vertical: 4,
                                            //               ),
                                            //           child: Text(
                                            //             "Answer",
                                            //             style:
                                            //                 GoogleFonts.outfit(
                                            //                   color:
                                            //                       Colors.black,
                                            //                   fontSize:
                                            //                       screenWidth *
                                            //                       0.035,
                                            //                   fontWeight:
                                            //                       FontWeight
                                            //                           .w600,
                                            //                 ),
                                            //           ),
                                            //         ),
                                            //       ),
                                            //     ),
                                            //   ),
                                          ],
                                        ),

                                        SizedBox(height: screenHeight * 0.015),

                                        /// QUESTION TEXT
                                        Text(
                                          question.content ?? '',
                                          style: GoogleFonts.outfit(
                                            color: Colors.black,
                                            fontSize: screenWidth * 0.040,
                                            fontWeight: FontWeight.w400,
                                            height: 1.25,
                                          ),
                                        ),

                                        SizedBox(height: screenHeight * 0.02),

                                        /// ANSWER LAYOUT (IF ANSWER EXISTS)
                                        if (question.answer != null)
                                          Container(
                                            decoration: BoxDecoration(
                                              color: Colors.white,
                                              borderRadius:
                                                  BorderRadius.circular(12),
                                              border: Border.all(
                                                color: const Color(0xFFC1A460),
                                              ),
                                            ),
                                            padding: EdgeInsets.all(
                                              screenWidth * 0.035,
                                            ),
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                // Expert Remark + Green Dot
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    Container(
                                                      padding:
                                                          EdgeInsets.symmetric(
                                                            vertical:
                                                                screenHeight *
                                                                0.005,
                                                            horizontal:
                                                                screenWidth *
                                                                0.025,
                                                          ),
                                                      decoration: BoxDecoration(
                                                        color:
                                                            const Color.fromRGBO(
                                                              243,
                                                              186,
                                                              54,
                                                              0.4,
                                                            ),
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                              10,
                                                            ),
                                                        border: Border.all(
                                                          color: Colors.white,
                                                        ),
                                                      ),
                                                      child: Text(
                                                        "Expert Remark",
                                                        style:
                                                            GoogleFonts.outfit(
                                                              color:
                                                                  const Color(
                                                                    0xFF2D2319,
                                                                  ),
                                                              fontSize:
                                                                  screenWidth *
                                                                  0.035,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w400,
                                                              height: 1.0,
                                                            ),
                                                      ),
                                                    ),
                                                    Container(
                                                      width: screenWidth * 0.03,
                                                      height:
                                                          screenWidth * 0.03,
                                                      decoration:
                                                          const BoxDecoration(
                                                            color: Color(
                                                              0xFF04C527,
                                                            ),
                                                            shape:
                                                                BoxShape.circle,
                                                          ),
                                                    ),
                                                  ],
                                                ),

                                                SizedBox(
                                                  height: screenHeight * 0.015,
                                                ),

                                                // Answer Content
                                                buildLinkText(
                                                  question.answer!.content ??
                                                      '',

                                                  normalStyle:
                                                      GoogleFonts.outfit(
                                                        color: const Color(
                                                          0xFF2D2319,
                                                        ),
                                                        fontSize:
                                                            screenWidth * 0.035,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                        height: 1.25,
                                                      ),
                                                ),

                                                SizedBox(
                                                  height: screenHeight * 0.015,
                                                ),

                                                // Answer by Icon + Text
                                                Row(
                                                  children: [
                                                    question?.answer?.role ==
                                                            "legal_expert"
                                                        ? Consumer<
                                                            ProfileProvider
                                                          >(
                                                            builder:
                                                                (
                                                                  context,
                                                                  profileProv,
                                                                  _,
                                                                ) {
                                                                  return CircleAvatar(
                                                                    radius:
                                                                        screenWidth *
                                                                        0.035,
                                                                    backgroundColor:
                                                                        Colors
                                                                            .grey
                                                                            .shade300,
                                                                    backgroundImage:
                                                                        profileProv.hasProfilePhoto &&
                                                                            profileProv.profilePhotoUrl !=
                                                                                null
                                                                        ? NetworkImage(
                                                                            "${profileProv.profilePhotoUrl}?v=${DateTime.now().millisecondsSinceEpoch}",
                                                                          )
                                                                        : const AssetImage(
                                                                                AppAssets.userIcon,
                                                                              )
                                                                              as ImageProvider,
                                                                  );
                                                                },
                                                          )
                                                        : Image.asset(
                                                            AppAssets.appIcon,
                                                            width:
                                                                screenWidth *
                                                                0.08,
                                                            height:
                                                                screenWidth *
                                                                0.08,
                                                          ),
                                                    SizedBox(
                                                      width:
                                                          screenWidth * 0.025,
                                                    ),
                                                    Text(
                                                      question
                                                          ?.answer
                                                          ?.answeredBy,
                                                      style: GoogleFonts.outfit(
                                                        color: const Color(
                                                          0xFF2D2319,
                                                        ),
                                                        fontSize:
                                                            screenWidth * 0.035,
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        height: 1.0,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ),

                                        SizedBox(height: screenHeight * 0.015),
                                        // if (_openedCommentQuestionId !=
                                        //     questionId)
                                        /// COMMENT LAYOUT (Tappable)
                                        GestureDetector(
                                          onTap: () {
                                            // final commentProvider = context
                                            //     .read<CommentProvider>();
                                            // showAskDoubtBottomSheet(
                                            //   context,
                                            //   commentProvider,
                                            //   "dark",
                                            //   questionId,
                                            //   userName,
                                            //   userRole,
                                            //   userPhone,
                                            //   profilImgUrl,
                                            //   question,
                                            // );

                                            final commentProvider = context
                                                .read<CommentProvider>();

                                            if (_openedCommentQuestionId !=
                                                questionId) {
                                              commentProvider
                                                  .clearExistingComments();
                                              commentProvider.fetchComments(
                                                questionId,
                                                reset: true,
                                              );
                                            }

                                            toggleComments(questionId);

                                            scrollToQuestion(questionId);
                                          },
                                          child:
                                              /// 🔥 ALWAYS SHOW ROW
                                              Container(
                                                width: double.infinity,
                                                child: Row(
                                                  children: [
                                                    /// 🔘 COMMENT BUTTON (ONLY HIDE THIS)
                                                    if (_openedCommentQuestionId !=
                                                        questionId)
                                                      GestureDetector(
                                                        onTap: () {
                                                          final commentProvider =
                                                              context
                                                                  .read<
                                                                    CommentProvider
                                                                  >();

                                                          if (_openedCommentQuestionId !=
                                                              questionId) {
                                                            commentProvider
                                                                .clearExistingComments();
                                                            commentProvider
                                                                .fetchComments(
                                                                  questionId,
                                                                  reset: true,
                                                                );
                                                          }

                                                          toggleComments(
                                                            questionId,
                                                          );
                                                          scrollToQuestion(
                                                            questionId,
                                                          );
                                                        },
                                                        child: Container(
                                                          height:
                                                              screenHeight *
                                                              0.045,
                                                          padding:
                                                              EdgeInsets.symmetric(
                                                                horizontal:
                                                                    screenWidth *
                                                                    0.04,
                                                                vertical:
                                                                    screenHeight *
                                                                    0.01,
                                                              ),
                                                          decoration: BoxDecoration(
                                                            color:
                                                                const Color.fromARGB(
                                                                  255,
                                                                  217,
                                                                  188,
                                                                  121,
                                                                ),
                                                            borderRadius:
                                                                BorderRadius.circular(
                                                                  22,
                                                                ),
                                                            boxShadow: [
                                                              BoxShadow(
                                                                color: Colors
                                                                    .black
                                                                    .withOpacity(
                                                                      0.33,
                                                                    ),
                                                                blurRadius: 3.5,
                                                              ),
                                                            ],
                                                          ),
                                                          child: Row(
                                                            mainAxisSize:
                                                                MainAxisSize
                                                                    .min,
                                                            children: [
                                                              Image.asset(
                                                                AppAssets
                                                                    .cmmIcon,
                                                                width:
                                                                    screenWidth *
                                                                    0.05,
                                                                height:
                                                                    screenWidth *
                                                                    0.05,
                                                                color: Colors
                                                                    .black
                                                                    .withOpacity(
                                                                      0.50,
                                                                    ),
                                                              ),
                                                              SizedBox(
                                                                width:
                                                                    screenWidth *
                                                                    0.025,
                                                              ),
                                                              Text(
                                                                "${question.commentsCount ?? 0}",
                                                                style: GoogleFonts.outfit(
                                                                  color: Colors
                                                                      .black,
                                                                  fontSize:
                                                                      screenWidth *
                                                                      0.037,
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),

                                                    /// 🔥 SPACE BETWEEN BUTTONS
                                                    if (_openedCommentQuestionId !=
                                                        questionId)
                                                      SizedBox(
                                                        width:
                                                            screenWidth * 0.02,
                                                      ),

                                                    /// 🔥 ANSWER BUTTON (OPTIONAL KEEP ALWAYS OR SAME LOGIC)
                                                    if (showAddAnswerButton)
                                                      Container(
                                                        height:
                                                            screenHeight *
                                                            0.035,
                                                        child: ElevatedButton(
                                                          onPressed: () {
                                                            _showAddAnswerDialog(
                                                              context,
                                                              questionId,
                                                              userName!,
                                                              userRole!,
                                                              question.phone
                                                                  as String,
                                                            );
                                                          },
                                                          style: ElevatedButton.styleFrom(
                                                            padding:
                                                                EdgeInsets.zero,
                                                            backgroundColor:
                                                                Colors
                                                                    .transparent,
                                                            elevation: 0,
                                                            shape: RoundedRectangleBorder(
                                                              borderRadius:
                                                                  BorderRadius.circular(
                                                                    6,
                                                                  ),
                                                            ),
                                                          ),
                                                          child: Ink(
                                                            decoration: BoxDecoration(
                                                              gradient: const LinearGradient(
                                                                colors: [
                                                                  Color(
                                                                    0xFFD29F2A,
                                                                  ),
                                                                  Color(
                                                                    0xFFFFFFFF,
                                                                  ),
                                                                ],
                                                              ),
                                                              borderRadius:
                                                                  BorderRadius.circular(
                                                                    6,
                                                                  ),
                                                            ),
                                                            child: Container(
                                                              padding:
                                                                  const EdgeInsets.symmetric(
                                                                    horizontal:
                                                                        8,
                                                                    vertical: 5,
                                                                  ),
                                                              child: Text(
                                                                "Answer",
                                                                style: GoogleFonts.outfit(
                                                                  color: Colors
                                                                      .black,
                                                                  fontSize:
                                                                      screenWidth *
                                                                      0.035,
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .w600,
                                                                ),
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),

                                                    /// 🔥 PUSH TIME RIGHT
                                                    const Spacer(),

                                                    /// ⏱ TIME (ALWAYS VISIBLE NOW ✅)
                                                    Text(
                                                      timeAgo(
                                                        question.timestamp,
                                                      ),
                                                      style: GoogleFonts.outfit(
                                                        color: const Color(
                                                          0xFF2D2319,
                                                        ),
                                                        fontSize:
                                                            screenWidth * 0.035,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                        ),

                                        if (_openedCommentQuestionId ==
                                            questionId)
                                          InlineCommentsSection(
                                            questionId: questionId,
                                            userName: userName,
                                            userRole: userRole,
                                            userPhone: question.phone as String,
                                            profileImgUrl: profilImgUrl,
                                            tappedCommentId:
                                                widget.tappedCommentId,
                                            onClose: () {
                                              setState(() {
                                                _openedCommentQuestionId = null;
                                              });
                                            },
                                            isLight: true,
                                          ),
                                      ],
                                    ),
                                  );
                                },
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            left: 0,
            right: 0,
            bottom: 0,
            child: Align(
              alignment: Alignment.bottomCenter,
              child: const CustomBottomNav(),
            ),
          ),
        ],
      ),
    );
  }
}
