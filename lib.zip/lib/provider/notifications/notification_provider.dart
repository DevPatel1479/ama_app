import 'dart:convert';
import 'package:ama_legal_solutions/api/api_service.dart';
import 'package:ama_legal_solutions/api/endpoints.dart';
import 'package:ama_legal_solutions/custom_messages_widgets/custom_flushbar_message.dart';
import 'package:ama_legal_solutions/db/storage/local/local_storage_helper.dart'
    show LocalStorageHelper;

import 'package:ama_legal_solutions/models/notification_model.dart';
import 'package:flutter/material.dart';

class NotificationProvider with ChangeNotifier {
  final ApiService _apiService = ApiService();

  bool _isLoading = false;
  bool get isLoading => _isLoading;

  int? _lastOpenedNotificationTime;

  int? get lastOpenedNotificationTime => _lastOpenedNotificationTime;

  List<NotificationModel> _notifications = [];
  List<NotificationModel> get notifications => _notifications;
  bool _hasFetchedLastSeen = false;
  String? _lastDocId;
  final int _limit = 10;
  bool _hasMore = true;
  bool get hasMore => _hasMore;

  Future<void> fetchLastOpenedNotificationTime({required String phone}) async {
    try {
      final response = await _apiService.post(Endpoints.lastSeenNotification, {
        "phone": phone,
      });

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data['success'] == true) {
          _lastOpenedNotificationTime = data['lastOpenedNotificationTime'];
        }
      }
    } catch (e) {
      debugPrint("Failed to fetch last opened time: $e");
    }
  }

  Future<void> updateLastOpenedNotificationTime({required String phone}) async {
    try {
      final response = await _apiService.post(Endpoints.markNotificationSeen, {
        "phone": phone,
      });
      print(response.body);

      // Locally update to avoid refetch
      _lastOpenedNotificationTime =
          DateTime.now().millisecondsSinceEpoch ~/ 1000;
    } catch (e) {
      debugPrint("Failed to update last opened time: $e");
    }
  }

  /// Send notification to specific topic or role
  Future<void> sendNotification({
    required BuildContext context,
    required String userId,
    required String topic,
    required String title,
    required String body,
    List<String>? topics,
    bool send_weekly = false,
  }) async {
    _isLoading = true;
    notifyListeners();

    try {
      final response = await _apiService
          .post(Endpoints.sendTopicNotifications, {
            "user_id": userId,
            "topic": (topic.isEmpty || topic == "") ? topics : topic,
            "n_title": title,
            "n_body": body,
            if (send_weekly) "send_weekly": true,
          });

      final data = jsonDecode(response.body);
      print(data);
      if (response.statusCode == 200 && data['success'] == true) {
        showCustomMessage(
          context,
          data['message'] ?? "Notification sent!",
          false,
        );
      } else {
        showCustomMessage(
          context,
          data['message'] ?? "Failed to send notification",
          true,
        );
      }
    } catch (e) {
      showCustomMessage(context, "Error: ${e.toString()}", true);
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// ✅ Fetch notifications with proper pagination and duplicate prevention
  Future<void> fetchNotifications({
    required BuildContext context,
    required String role,
    bool loadMore = false,
  }) async {
    if (loadMore && !_hasMore) return;
    final phone = await LocalStorageHelper.getString("userPhone");
    // print(loadMore);
    // print(_currentPage);
    // print(_hasFetchedLastSeen);
    if (!_hasFetchedLastSeen) {
      await fetchLastOpenedNotificationTime(phone: phone ?? "");
      _hasFetchedLastSeen = true;
    }
    if (!loadMore) {
      _lastDocId = null;
      _notifications.clear();
      _hasMore = true;
    }

    _isLoading = true;
    notifyListeners();

    try {
      final response = await _apiService.get(
        "${Endpoints.getNotifications(role)}?phone=$phone&limit=$_limit${_lastDocId != null ? "&lastDocId=$_lastDocId" : ""}",
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data['success'] == true) {
          final newNotifications = NotificationModel.fromJsonList(
            response.body,
          );

          _lastDocId = data['lastDocId'];
          _hasMore = data['hasMore'] ?? false;
          // ✅ Remove duplicates based on notification ID
          final existingIds = _notifications.map((n) => n.id).toSet();
          final uniqueNew = newNotifications
              .where((n) => !existingIds.contains(n.id))
              .toList();

          _notifications.addAll(uniqueNew);

          print(_notifications.first.timestamp);

          notifyListeners();
        } else {
          showCustomMessage(
            context,
            data['message'] ?? "No notifications found",
            true,
          );
          _hasMore = false;
        }
      } else {
        showCustomMessage(
          context,
          "Failed with code ${response.statusCode}",
          true,
        );
      }
    } catch (e) {
      // print(e.toString());
      if (!e.toString().contains("Bad state: No element")) {
        showCustomMessage(context, "Error: ${e.toString()}", true);
      }
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  bool get hasUnreadNotifications {
    if (_notifications.isEmpty) return false;

    // if user never opened notification screen yet
    if (_lastOpenedNotificationTime == null) return true;

    return _notifications.any((n) {
      final notifSeconds = n.timestamp; // already unix seconds
      return notifSeconds > _lastOpenedNotificationTime!;
    });
  }

  void clearNotifications() {
    _notifications.clear();
    _hasMore = true;

    _isLoading = true;
    _hasFetchedLastSeen = false;
    _lastOpenedNotificationTime = null;

    notifyListeners();
  }
}
