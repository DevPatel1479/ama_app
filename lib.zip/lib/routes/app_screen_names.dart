class AppScreenNames {
  static const String splash = "splash";
  static const String userHome = "user_home";
  static const String getStarted = "get_started";
  static const String signUp = "sign_up";
  static const String logIn = "log_in";
  static const String userAccount = "userAccount";
  static const String portfolio = "portfolio";
  static const String ama = "ama";
  static const String caseDesk = "case_desk";
  static const String amaServices = "ama_services";
  static const String raiseQuery = "raise_query";
  static const String advocateCaseDesk = "advocate_case_desk";
  static const String notificationScreen = "notification";
  static const String policyScreen = "policy_screen";
  static const String termsAndConditionsScreen = "terms_and_conditions";
  static const String deleteAccountScreen = "delete_account_screen";
  static const String acceptPolicyScreen = "accept_policy_screen";
  static const String deleteAccountRequestScreen =
      "delete_account_request_screen";
  static const String notificationHistoryScreen = "notification_history_screen";

  static const String overviewCaseDeskScreen = "overview_case_desk_screen";

  static const String paymentViewScreen = "payment_view_screen";

  static const String liveCaseStatusScreen = "live_case_status_screen";

  static const String bankDetailsScreen = "bank_details_screen";

  static const String askLawyerScreen = "ask_lawyer_screen";

  static const String meetTeamScreen = "meet_team_screen";

  static const String amaLeadsScreen = "ama_leads_screen";
  static const String adminAmaLeadsScreen = "admin_ama_leads_screen";
}
